from tkinter import *
from tkinter import ttk
from tkinter import filedialog
from tkinter import messagebox
from PIL import ImageTk, Image
import numpy as np
import matplotlib.pyplot as plt
import json_data
import __main__
import os, sys
from configparser import ConfigParser




HEIGHT=50
WIDTH=250


class Base:

    def __init__(self, root):

        topFrame=Frame(root)
        topFrame.pack()
        bottomFrame=Frame(root)
        bottomFrame.pack()

        #***************** BUTTONS **********************

        #***** File Button ********
        oFile=File()
        click=PhotoImage(file="file.png")
        #para usar com imagens no botao
        #, image=click, activeforeground="white", activebackground="grey"
        self.fileButton=ttk.Button(topFrame, text="Open a File", image=click, compound=TOP, command=oFile.openFile) #no ttk nao ha activeforeground e activebackground
        self.fileButton.image=click
        self.fileButton.pack(side=LEFT)

        # ***** Folder Button ********
        oFolder=Folder()
        fold=PhotoImage(file="folder.png")
        #, image=fold, activeforeground="white", activebackground="grey"
        self.folderButton = ttk.Button(topFrame, text="Open a Folder", image=fold, compound=TOP, command=oFolder.openFolder)
        self.folderButton.image = fold
        self.folderButton.pack(side=LEFT)

        # ***** Quit Button ********
        quitt=PhotoImage(file="quit.png") #quitt com 2 "t" prq no command entrava em conflito e nao fechava a janela
        self.quitButton=ttk.Button(topFrame, text="Quit", image=quitt, compound=TOP, command=quit)
        self.quitButton.image=quitt
        self.quitButton.pack(side=LEFT)

        # ********* Status Bar *************
        status = ttk.Label(root, text="By Critical Software Developers", relief=SUNKEN, anchor=S)  # bd é border/ no ttk nao ha border
        status.pack(side=BOTTOM, fill=X)



class Menus:

    def __init__(self, root):
        menu = Menu(root)
        root.config(menu=menu)  # estamos a configurar um menu para o software. o tkinter ja sabe onde por o menu

        # ********* File Sub-Menu *************
        fileMenu = Menu(menu, tearoff=0)
        menu.add_cascade(label="File", menu=fileMenu)  # para adicionar um menu dropdown
        fileMenu.add_command(label="New Project", accelerator='Ctrl+N', command=FileMenu.doNothing)
        fileMenu.add_command(label="New File", accelerator='Ctrl+F', command=FileMenu.doNothing)
        fileMenu.add_command(label="Properties", accelerator='Ctrl+P', command=FileMenu.properties)
        fileMenu.add_separator()  # cria uma linha para dividir as secoes do menu
        fileMenu.add_command(label="Exit", accelerator='Alt+F4', command=quit)

        # ********* Edit Sub-Menu *************
        editMenu = Menu(menu, tearoff=0)
        menu.add_cascade(label="Edit", menu=editMenu)
        editMenu.add_command(label="Redo", command=Menus.doNothing)

        # ********* View Sub-Menu *************
        viewMenu = Menu(menu, tearoff=0)
        menu.add_cascade(label="View", menu=viewMenu)
        viewMenu.add_command(label="View Histogram", command=Graphs.hist)
        #viewMenu.add_command(label="View Pie", command=Graphs.pie)

        # ********* Help Sub-Menu *************
        helpMenu = Menu(menu, tearoff=0)
        menu.add_cascade(label="Help", menu=helpMenu)
        helpMenu.add_command(label="Save me", command=Menus.doNothing)

    def doNothing():
        print("Hey, i'm not ready to work yet!")

class FileMenu:
    clicked = ''                #variavel global onde vai ficar guardada a opcao escolhida no menu
    config = ConfigParser()     #para se poder aceder ao config.ini
    config.read('config.ini')
    sections=config.sections()
    options=[]                  #criei esta lista para guardar as secoes do cofig.ini para as poder colocar nas opcoes do menu
    for section in sections:
        options.append(section)
    options.pop(0)              #desta maneira conseguimos garantir que nunca apanha o 1º elementos das secoes AKA o Default


    @staticmethod
    def choice(*args):
        #print(FileMenu.clicked.get())
        # if FileMenu.clicked.get()== FileMenu.config['lotrain']:
        #     print(FileMenu.config.get('lotrain', 'project'))
        # elif FileMenu.clicked.get()== FileMenu.config['ea']:
        #     print(FileMenu.config.get('ea', 'project'))
        if FileMenu.clicked.get()== FileMenu.options[0]:
            print(FileMenu.config.get('lotrain', 'project'))            #está a imprimir isto 3 vezes..
        elif FileMenu.clicked.get()== FileMenu.options[1]:
            print(FileMenu.config.get('ea', 'project'))                 #está a imprimir isto 3 vezes..


    @staticmethod
    def properties():
        prop_window = Toplevel()
        prop_window.title('Properties')
        prop_window.iconbitmap('csw.ico')
        prop_window.geometry("300x150")


        FileMenu.clicked = StringVar()
        #FileMenu.clicked.set(FileMenu.options[1])     ######ver como se faz para assumir a 2a posicao da sections como default
        FileMenu.clicked.trace("w", FileMenu.choice)


        pn_label = ttk.Label(prop_window,text="Project Name:", compound=LEFT)    #project name label
        pn_label.grid()
        drop = ttk.OptionMenu(prop_window, FileMenu.clicked, FileMenu.options[0], *FileMenu.options, command=FileMenu.choice)
        drop.grid(row=0, column=1, sticky=W)

        pp_label=ttk.Label(prop_window, text="Project Path:")                    #project path label
        pp_label.grid(row=1)
        if FileMenu.clicked.get()==FileMenu.options[0]:
            e1 = ttk.Label(prop_window, text=FileMenu.config.get(FileMenu.clicked.get(), 'project'))    #estao a aparecer sozinhos e nao mudam para o ea quando é escolhido
            e1.grid(row=1, column=1, sticky=W)
        elif FileMenu.clicked.get()==FileMenu.options[1]:
            print("estou a entrar aqui")
            e1 = ttk.Label(prop_window,text=FileMenu.config.get(FileMenu.clicked.get(), 'project'))
            e1.grid(row=1, column=1, sticky=W)

        gp_label = ttk.Label(prop_window, text="Generic Path:")                 # generic project label
        gp_label.grid(row=2)
        if FileMenu.clicked.get()==FileMenu.options[0]:
            e2=ttk.Label(prop_window, text=FileMenu.config.get(FileMenu.clicked.get(), 'generic_pad'))
            e2.grid(row=2, column=1, sticky=W)
        elif FileMenu.clicked.get()==FileMenu.options[1]:
            print("estou a entrar aqui")
            e2 = ttk.Label(prop_window,text=FileMenu.config.get(FileMenu.clicked.get(), 'generic_pad'))
            e2.grid(row=2, column=1, sticky=W)


    def doNothing():
        print("Hey, i'm not ready to work yet!")


class Graphs:

    def hist():
        house_prices=np.random.normal(200000, 25000, 5000)
        plt.hist(house_prices, 100)
        plt.show()

    #def pie():
        # house_prices = np.random.normal(200000, 25000, 5000)
        # plt.pie(house_prices)
        # plt.show()


class File:

    def openFile(self):
        self.filename =filedialog.askopenfilename(initialdir="./interface", title="Select a File", filetypes=(("all files", "*.*"),("txt files", "*.txt")))

        try:
            if self.filename:
                f=open(self.filename, "r")
                #         self.open_file=f
                #         self.text_area.display_file_contents(f)
                Label(root, text=f.read()).pack()
                f.close()
            elif self.filename=='':
                messagebox.showinfo("Cancel", "You clicked Cancel")
        except IOError:
            messagebox.showinfo("Error", "Could not open file")


class Folder:

    def openFolder(self):
        path = filedialog.askdirectory()
        dirs=os.listdir(path)
        self.load_files(dirs)


    def load_files(self, dirs):
        fileList=[dirs]

        for file in dirs:
            f_label=Label(root, text=file)
            f_label.pack()
            print()




root=Tk()
root.title('Interface analise ficheiros')
root.iconbitmap('csw.ico')
root.geometry("300x150")



#canvas=Canvas(root,width=WIDTH,height=HEIGHT).pack()
m=Menus(root)
b=Base(root)




root.mainloop()