"""
"""
json_data = {
    "data": [
        {
            "id": "442946",
            "status_table": [
                {
                    "elapsed": "0:00:09",
                    "end_date": "Tue, 17 Mar 2020 10:57:19 GMT",
                    "start_date": "Tue, 17 Mar 2020 10:57:10 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "6 days, 5:08:56",
                    "end_date": "Mon, 23 Mar 2020 16:06:16 GMT",
                    "start_date": "Tue, 17 Mar 2020 10:57:19 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "1:06:40",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Mon, 23 Mar 2020 16:06:16 GMT",
                    "status": "Deciding"
                }
            ],
            "title": "[FCR 047624] Alarm issue Trigger Train Clearance Mode without Active Cab"
        },
        {
            "id": "433614",
            "status_table": [
                {
                    "elapsed": "0:00:07",
                    "end_date": "Wed, 26 Feb 2020 05:52:52 GMT",
                    "start_date": "Wed, 26 Feb 2020 05:52:44 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "21 days, 8:04:53",
                    "end_date": "Wed, 18 Mar 2020 13:57:45 GMT",
                    "start_date": "Wed, 26 Feb 2020 05:52:52 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "1 day, 23:29:07",
                    "end_date": "Fri, 20 Mar 2020 13:26:52 GMT",
                    "start_date": "Wed, 18 Mar 2020 13:57:45 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "3 days, 3:46:03",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Fri, 20 Mar 2020 13:26:52 GMT",
                    "status": "Pending Impl."
                }
            ],
            "title": "Location confirmed is setting to TRUE while setting any invalid station ID through RFID Tag, causing Command of ClearCsde not setting to TRUE."
        },
        {
            "id": "432921",
            "status_table": [
                {
                    "elapsed": "0:00:06",
                    "end_date": "Mon, 24 Feb 2020 14:37:27 GMT",
                    "start_date": "Mon, 24 Feb 2020 14:37:21 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "28 days, 2:35:29",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Mon, 24 Feb 2020 14:37:27 GMT",
                    "status": "Analysing"
                }
            ],
            "title": "[TPR 420526] 24-7869_D 6.1.2.2 steps 6, 7 and 8 doors incorrectly releasing when activated from cab."
        },
        {
            "id": "430883",
            "status_table": [
                {
                    "elapsed": "0:00:07",
                    "end_date": "Wed, 19 Feb 2020 13:25:27 GMT",
                    "start_date": "Wed, 19 Feb 2020 13:25:19 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "25 days, 4:44:26",
                    "end_date": "Sun, 15 Mar 2020 18:09:53 GMT",
                    "start_date": "Wed, 19 Feb 2020 13:25:27 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "4 days, 19:17:31",
                    "end_date": "Fri, 20 Mar 2020 13:27:25 GMT",
                    "start_date": "Sun, 15 Mar 2020 18:09:53 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "3 days, 3:45:31",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Fri, 20 Mar 2020 13:27:25 GMT",
                    "status": "Pending Impl."
                }
            ],
            "title": "[TPR 418770][TPR 418766] TCMS defect: \"Update timings of CCUO_CCUC_I1.ISDO incorrect\""
        },
        {
            "id": "430879",
            "status_table": [
                {
                    "elapsed": "0:05:03",
                    "end_date": "Wed, 19 Feb 2020 13:28:17 GMT",
                    "start_date": "Wed, 19 Feb 2020 13:23:14 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "25 days, 4:48:14",
                    "end_date": "Sun, 15 Mar 2020 18:16:32 GMT",
                    "start_date": "Wed, 19 Feb 2020 13:28:17 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "4 days, 19:13:13",
                    "end_date": "Fri, 20 Mar 2020 13:29:46 GMT",
                    "start_date": "Sun, 15 Mar 2020 18:16:32 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "3 days, 3:43:10",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Fri, 20 Mar 2020 13:29:46 GMT",
                    "status": "Duplicate"
                }
            ],
            "title": "[TPR 418766] TCMS defect: \"Incorrect SDO release pattern sent from CCUO to CCUC as part of signal CCUO_CCUC_I1.ISDO\""
        },
        {
            "id": "430345",
            "status_table": [
                {
                    "elapsed": "0:00:13",
                    "end_date": "Tue, 18 Feb 2020 15:58:56 GMT",
                    "start_date": "Tue, 18 Feb 2020 15:58:43 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "34 days, 1:14:00",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Tue, 18 Feb 2020 15:58:56 GMT",
                    "status": "Analysing"
                }
            ],
            "title": "[TPR 425615] Door configuration issues due to changing ends after override"
        },
        {
            "id": "430341",
            "status_table": [
                {
                    "elapsed": "0:00:53",
                    "end_date": "Tue, 18 Feb 2020 15:55:34 GMT",
                    "start_date": "Tue, 18 Feb 2020 15:54:40 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "34 days, 1:17:22",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Tue, 18 Feb 2020 15:55:34 GMT",
                    "status": "Analysing"
                }
            ],
            "title": "[TPR 419881] Unsafe door release in Multiple Unit"
        },
        {
            "id": "429645",
            "status_table": [
                {
                    "elapsed": "0:00:22",
                    "end_date": "Mon, 17 Feb 2020 09:11:55 GMT",
                    "start_date": "Mon, 17 Feb 2020 09:11:33 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "35 days, 8:01:01",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Mon, 17 Feb 2020 09:11:55 GMT",
                    "status": "Analysing"
                }
            ],
            "title": "[TPR 365188] Unsafe door release (and override) when train first boarded"
        },
        {
            "id": "418798",
            "status_table": [
                {
                    "elapsed": "0:00:25",
                    "end_date": "Tue, 21 Jan 2020 12:30:20 GMT",
                    "start_date": "Tue, 21 Jan 2020 12:29:55 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "62 days, 4:42:36",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Tue, 21 Jan 2020 12:30:20 GMT",
                    "status": "Analysing"
                }
            ],
            "title": "[TPR 416425] LO_24-9278 Section 6.1.1.2 No CSDE Warning at expected location"
        },
        {
            "id": "416899",
            "status_table": [
                {
                    "elapsed": "0:02:38",
                    "end_date": "Fri, 17 Jan 2020 04:55:43 GMT",
                    "start_date": "Fri, 17 Jan 2020 04:53:05 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "66 days, 12:17:13",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Fri, 17 Jan 2020 04:55:43 GMT",
                    "status": "Analysing"
                }
            ],
            "title": "SAS-REQ-054 is failing for SA6 to SA4 application"
        },
        {
            "id": "365699",
            "status_table": [
                {
                    "elapsed": "3 days, 15:35:45",
                    "end_date": "Tue, 27 Aug 2019 03:58:21 GMT",
                    "start_date": "Fri, 23 Aug 2019 12:22:35 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "154 days, 12:01:47",
                    "end_date": "Tue, 28 Jan 2020 16:00:09 GMT",
                    "start_date": "Tue, 27 Aug 2019 03:58:21 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "42 days, 5:03:35",
                    "end_date": "Tue, 10 Mar 2020 21:03:44 GMT",
                    "start_date": "Tue, 28 Jan 2020 16:00:09 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "18:15:37",
                    "end_date": "Wed, 11 Mar 2020 15:19:22 GMT",
                    "start_date": "Tue, 10 Mar 2020 21:03:44 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "0:06:43",
                    "end_date": "Wed, 11 Mar 2020 15:26:06 GMT",
                    "start_date": "Wed, 11 Mar 2020 15:19:22 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "21:32:34",
                    "end_date": "Thu, 12 Mar 2020 12:58:40 GMT",
                    "start_date": "Wed, 11 Mar 2020 15:26:06 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "3:15:26",
                    "end_date": "Thu, 12 Mar 2020 16:14:06 GMT",
                    "start_date": "Thu, 12 Mar 2020 12:58:40 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "0:43:41",
                    "end_date": "Thu, 12 Mar 2020 16:57:47 GMT",
                    "start_date": "Thu, 12 Mar 2020 16:14:06 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "5 days, 2:06:23",
                    "end_date": "Tue, 17 Mar 2020 19:04:11 GMT",
                    "start_date": "Thu, 12 Mar 2020 16:57:47 GMT",
                    "status": "Verifying"
                },
                {
                    "elapsed": "0:00:21",
                    "end_date": "Tue, 17 Mar 2020 19:04:32 GMT",
                    "start_date": "Tue, 17 Mar 2020 19:04:11 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "5 days, 22:08:24",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Tue, 17 Mar 2020 19:04:32 GMT",
                    "status": "Pending Impl."
                }
            ],
            "title": "The ASDO safe test button is not enabled once the test is passed on HMI"
        },
        {
            "id": "345206",
            "status_table": [
                {
                    "elapsed": "0:07:39",
                    "end_date": "Mon, 24 Jun 2019 10:22:57 GMT",
                    "start_date": "Mon, 24 Jun 2019 10:15:18 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "24 days, 20:32:04",
                    "end_date": "Fri, 19 Jul 2019 06:55:02 GMT",
                    "start_date": "Mon, 24 Jun 2019 10:22:57 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "206 days, 10:23:53",
                    "end_date": "Mon, 10 Feb 2020 17:18:55 GMT",
                    "start_date": "Fri, 19 Jul 2019 06:55:02 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "0:00:03",
                    "end_date": "Mon, 10 Feb 2020 17:18:59 GMT",
                    "start_date": "Mon, 10 Feb 2020 17:18:55 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "23:29:54",
                    "end_date": "Tue, 11 Feb 2020 16:48:54 GMT",
                    "start_date": "Mon, 10 Feb 2020 17:18:59 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "1 day, 18:06:08",
                    "end_date": "Thu, 13 Feb 2020 10:55:03 GMT",
                    "start_date": "Tue, 11 Feb 2020 16:48:54 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "6 days, 6:16:08",
                    "end_date": "Wed, 19 Feb 2020 17:11:11 GMT",
                    "start_date": "Thu, 13 Feb 2020 10:55:03 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "17 days, 21:10:25",
                    "end_date": "Sun, 08 Mar 2020 14:21:37 GMT",
                    "start_date": "Wed, 19 Feb 2020 17:11:11 GMT",
                    "status": "Verifying"
                },
                {
                    "elapsed": "0:00:06",
                    "end_date": "Sun, 08 Mar 2020 14:21:43 GMT",
                    "start_date": "Sun, 08 Mar 2020 14:21:37 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "0:00:03",
                    "end_date": "Sun, 08 Mar 2020 14:21:46 GMT",
                    "start_date": "Sun, 08 Mar 2020 14:21:43 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "2 days, 18:37:21",
                    "end_date": "Wed, 11 Mar 2020 08:59:08 GMT",
                    "start_date": "Sun, 08 Mar 2020 14:21:46 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "1 day, 3:58:21",
                    "end_date": "Thu, 12 Mar 2020 12:57:29 GMT",
                    "start_date": "Wed, 11 Mar 2020 08:59:08 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "4:00:42",
                    "end_date": "Thu, 12 Mar 2020 16:58:12 GMT",
                    "start_date": "Thu, 12 Mar 2020 12:57:29 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "0:00:11",
                    "end_date": "Thu, 12 Mar 2020 16:58:23 GMT",
                    "start_date": "Thu, 12 Mar 2020 16:58:12 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "5 days, 2:07:12",
                    "end_date": "Tue, 17 Mar 2020 19:05:36 GMT",
                    "start_date": "Thu, 12 Mar 2020 16:58:23 GMT",
                    "status": "Verifying"
                },
                {
                    "elapsed": "0:00:16",
                    "end_date": "Tue, 17 Mar 2020 19:05:52 GMT",
                    "start_date": "Tue, 17 Mar 2020 19:05:36 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "5 days, 22:07:04",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Tue, 17 Mar 2020 19:05:52 GMT",
                    "status": "Pending Impl."
                }
            ],
            "title": "ASDO Safe test events are not per DOOR"
        },
        {
            "id": "336593",
            "status_table": [
                {
                    "elapsed": "0:00:10",
                    "end_date": "Wed, 29 May 2019 07:43:47 GMT",
                    "start_date": "Wed, 29 May 2019 07:43:36 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "51 days, 0:20:54",
                    "end_date": "Fri, 19 Jul 2019 08:04:41 GMT",
                    "start_date": "Wed, 29 May 2019 07:43:47 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "5 days, 12:03:33",
                    "end_date": "Wed, 24 Jul 2019 20:08:14 GMT",
                    "start_date": "Fri, 19 Jul 2019 08:04:41 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "12:56:12",
                    "end_date": "Thu, 25 Jul 2019 09:04:27 GMT",
                    "start_date": "Wed, 24 Jul 2019 20:08:14 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "66 days, 23:02:12",
                    "end_date": "Mon, 30 Sep 2019 08:06:39 GMT",
                    "start_date": "Thu, 25 Jul 2019 09:04:27 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "1 day, 21:06:29",
                    "end_date": "Wed, 02 Oct 2019 05:13:08 GMT",
                    "start_date": "Mon, 30 Sep 2019 08:06:39 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "8 days, 4:14:34",
                    "end_date": "Thu, 10 Oct 2019 09:27:43 GMT",
                    "start_date": "Wed, 02 Oct 2019 05:13:08 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "20 days, 7:35:59",
                    "end_date": "Wed, 30 Oct 2019 17:03:42 GMT",
                    "start_date": "Thu, 10 Oct 2019 09:27:43 GMT",
                    "status": "Verifying"
                },
                {
                    "elapsed": "0:00:06",
                    "end_date": "Wed, 30 Oct 2019 17:03:49 GMT",
                    "start_date": "Wed, 30 Oct 2019 17:03:42 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "0:00:04",
                    "end_date": "Wed, 30 Oct 2019 17:03:53 GMT",
                    "start_date": "Wed, 30 Oct 2019 17:03:49 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "4 days, 21:26:41",
                    "end_date": "Mon, 04 Nov 2019 14:30:35 GMT",
                    "start_date": "Wed, 30 Oct 2019 17:03:53 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "1 day, 18:00:38",
                    "end_date": "Wed, 06 Nov 2019 08:31:14 GMT",
                    "start_date": "Mon, 04 Nov 2019 14:30:35 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "1 day, 0:46:18",
                    "end_date": "Thu, 07 Nov 2019 09:17:32 GMT",
                    "start_date": "Wed, 06 Nov 2019 08:31:14 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "1 day, 7:23:01",
                    "end_date": "Fri, 08 Nov 2019 16:40:33 GMT",
                    "start_date": "Thu, 07 Nov 2019 09:17:32 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "75 days, 17:17:51",
                    "end_date": "Thu, 23 Jan 2020 09:58:25 GMT",
                    "start_date": "Fri, 08 Nov 2019 16:40:33 GMT",
                    "status": "Verifying"
                },
                {
                    "elapsed": "0:00:46",
                    "end_date": "Thu, 23 Jan 2020 09:59:12 GMT",
                    "start_date": "Thu, 23 Jan 2020 09:58:25 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "0:00:04",
                    "end_date": "Thu, 23 Jan 2020 09:59:17 GMT",
                    "start_date": "Thu, 23 Jan 2020 09:59:12 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "0:03:26",
                    "end_date": "Thu, 23 Jan 2020 10:02:43 GMT",
                    "start_date": "Thu, 23 Jan 2020 09:59:17 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "7 days, 4:33:45",
                    "end_date": "Thu, 30 Jan 2020 14:36:29 GMT",
                    "start_date": "Thu, 23 Jan 2020 10:02:43 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "3 days, 4:00:07",
                    "end_date": "Sun, 02 Feb 2020 18:36:36 GMT",
                    "start_date": "Thu, 30 Jan 2020 14:36:29 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "0:00:04",
                    "end_date": "Sun, 02 Feb 2020 18:36:40 GMT",
                    "start_date": "Sun, 02 Feb 2020 18:36:36 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "2 days, 18:31:49",
                    "end_date": "Wed, 05 Feb 2020 13:08:30 GMT",
                    "start_date": "Sun, 02 Feb 2020 18:36:40 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "4 days, 21:51:00",
                    "end_date": "Mon, 10 Feb 2020 10:59:30 GMT",
                    "start_date": "Wed, 05 Feb 2020 13:08:30 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "9 days, 12:36:04",
                    "end_date": "Wed, 19 Feb 2020 23:35:34 GMT",
                    "start_date": "Mon, 10 Feb 2020 10:59:30 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "12 days, 15:16:08",
                    "end_date": "Tue, 03 Mar 2020 14:51:43 GMT",
                    "start_date": "Wed, 19 Feb 2020 23:35:34 GMT",
                    "status": "Verifying"
                },
                {
                    "elapsed": "0:00:08",
                    "end_date": "Tue, 03 Mar 2020 14:51:51 GMT",
                    "start_date": "Tue, 03 Mar 2020 14:51:43 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "0:00:04",
                    "end_date": "Tue, 03 Mar 2020 14:51:55 GMT",
                    "start_date": "Tue, 03 Mar 2020 14:51:51 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "0:11:28",
                    "end_date": "Tue, 03 Mar 2020 15:03:23 GMT",
                    "start_date": "Tue, 03 Mar 2020 14:51:55 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "4:09:19",
                    "end_date": "Tue, 03 Mar 2020 19:12:43 GMT",
                    "start_date": "Tue, 03 Mar 2020 15:03:23 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "0:00:15",
                    "end_date": "Tue, 03 Mar 2020 19:12:59 GMT",
                    "start_date": "Tue, 03 Mar 2020 19:12:43 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "0:00:09",
                    "end_date": "Tue, 03 Mar 2020 19:13:09 GMT",
                    "start_date": "Tue, 03 Mar 2020 19:12:59 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "5 days, 9:41:21",
                    "end_date": "Mon, 09 Mar 2020 04:54:30 GMT",
                    "start_date": "Tue, 03 Mar 2020 19:13:09 GMT",
                    "status": "Verifying"
                },
                {
                    "elapsed": "0:00:05",
                    "end_date": "Mon, 09 Mar 2020 04:54:35 GMT",
                    "start_date": "Mon, 09 Mar 2020 04:54:30 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "0:00:04",
                    "end_date": "Mon, 09 Mar 2020 04:54:39 GMT",
                    "start_date": "Mon, 09 Mar 2020 04:54:35 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "2 days, 3:54:41",
                    "end_date": "Wed, 11 Mar 2020 08:49:21 GMT",
                    "start_date": "Mon, 09 Mar 2020 04:54:39 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "1 day, 5:15:37",
                    "end_date": "Thu, 12 Mar 2020 14:04:59 GMT",
                    "start_date": "Wed, 11 Mar 2020 08:49:21 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "2:05:50",
                    "end_date": "Thu, 12 Mar 2020 16:10:49 GMT",
                    "start_date": "Thu, 12 Mar 2020 14:04:59 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "0:46:16",
                    "end_date": "Thu, 12 Mar 2020 16:57:06 GMT",
                    "start_date": "Thu, 12 Mar 2020 16:10:49 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "19:44:08",
                    "end_date": "Fri, 13 Mar 2020 12:41:14 GMT",
                    "start_date": "Thu, 12 Mar 2020 16:57:06 GMT",
                    "status": "Verifying"
                },
                {
                    "elapsed": "2 days, 22:48:08",
                    "end_date": "Mon, 16 Mar 2020 11:29:23 GMT",
                    "start_date": "Fri, 13 Mar 2020 12:41:14 GMT",
                    "status": "Implementing"
                },
                {
                    "elapsed": "0:00:23",
                    "end_date": "Mon, 16 Mar 2020 11:29:47 GMT",
                    "start_date": "Mon, 16 Mar 2020 11:29:23 GMT",
                    "status": "Pending Impl."
                },
                {
                    "elapsed": "7 days, 5:43:09",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Mon, 16 Mar 2020 11:29:47 GMT",
                    "status": "Analysing"
                }
            ],
            "title": "Maintainer ASDO Safe Test Result not setting to Failed because Event of ASDO Safe Test Fault for Car1/Car3 and Event of ASDO Redundancy Test Fault Car1/Car3 are not setting to TRUE."
        },
        {
            "id": "293251",
            "status_table": [
                {
                    "elapsed": "11 days, 21:16:47",
                    "end_date": "Mon, 04 Feb 2019 05:22:35 GMT",
                    "start_date": "Wed, 23 Jan 2019 08:05:47 GMT",
                    "status": "Created"
                },
                {
                    "elapsed": "85 days, 5:49:12",
                    "end_date": "Tue, 30 Apr 2019 11:11:48 GMT",
                    "start_date": "Mon, 04 Feb 2019 05:22:35 GMT",
                    "status": "Analysing"
                },
                {
                    "elapsed": "93 days, 5:36:31",
                    "end_date": "Thu, 01 Aug 2019 16:48:20 GMT",
                    "start_date": "Tue, 30 Apr 2019 11:11:48 GMT",
                    "status": "Deciding"
                },
                {
                    "elapsed": "235 days, 0:24:36",
                    "end_date": "Mon, 23 Mar 2020 17:12:56 GMT",
                    "start_date": "Thu, 01 Aug 2019 16:48:20 GMT",
                    "status": "Analysing"
                }
            ],
            "title": "[FCR 022083] CORE: packet 44 input for ASDO and CSDE"
        }
    ]
}