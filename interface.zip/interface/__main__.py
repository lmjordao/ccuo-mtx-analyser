"""

"""
from datetime import datetime

from src.json_data import json_data


def main():
    i = 0
    j = i + 1
    count_c=0
    count_a=0
    count_d=0

    datetime_object_total_c=None
    datetime_object_total_a=None
    datetime_object_total_d=None

    # print(json_data['data'][i]['status_table'][i]['status'])
    # print(json_data['data'][i]['status_table'][i]['start_date'])
    # print(json_data['data'][i]['status_table'][i]['end_date'])
    for i in range(0, len(json_data['data'])):
        for j in range(0, len(json_data['data'][i]['status_table'])):

            status = json_data['data'][i]['status_table'][j]['status']
            _end_date = json_data['data'][i]['status_table'][j]['end_date']
            _start_date = json_data['data'][i]['status_table'][j]['start_date']

            #datas do campo Created
            datetime_object_start_c = datetime.strptime(_start_date, '%a, %d %b %Y %H:%M:%S %Z')
            datetime_object_end_c = datetime.strptime(_end_date, '%a, %d %b %Y %H:%M:%S %Z')
            #datas do campo Analysing
            datetime_object_start_a = datetime.strptime(_start_date, '%a, %d %b %Y %H:%M:%S %Z')
            datetime_object_end_a = datetime.strptime(_end_date, '%a, %d %b %Y %H:%M:%S %Z')
            #datetime_object_total_a = datetime_object_end_a - datetime_object_start_a
            #datas do campo Deciding
            datetime_object_start_d = datetime.strptime(_start_date, '%a, %d %b %Y %H:%M:%S %Z')
            datetime_object_end_d = datetime.strptime(_end_date, '%a, %d %b %Y %H:%M:%S %Z')

            if status=='Created':
                count_c+=1
                datetime_object_dif_c = datetime_object_end_c - datetime_object_start_c
                if datetime_object_total_c==None:
                    datetime_object_total_c=datetime_object_dif_c
                datetime_object_total_c += datetime_object_dif_c
            if status == 'Analysing':
                count_a+=1
                datetime_object_dif_a = datetime_object_end_a - datetime_object_start_a
                if datetime_object_total_a==None:
                    datetime_object_total_a=datetime_object_dif_a
                datetime_object_total_a += datetime_object_dif_a
            if status=='Deciding':
                count_d+=1
                datetime_object_dif_d = datetime_object_end_d - datetime_object_start_d
                if datetime_object_total_d==None:
                    datetime_object_total_d=datetime_object_dif_d
                datetime_object_total_d += datetime_object_dif_d

            #print(datetime_object_end_a-datetime_object_start_a)
            #print(datetime_object_total_a)

    print("Total time creating:",datetime_object_total_c)
    atc=datetime_object_total_c / len(json_data['data'])
    print("Average time spent creating:",atc)
    print("Average time spent creating each id:", datetime_object_total_c / count_c)
    print("Total time analysing:",datetime_object_total_a)
    ata=datetime_object_total_a/len(json_data['data'])
    print("Average time spent analysing:",ata)
    print("Average time spent analysing each id:", datetime_object_total_a / count_a)
    print("Total time deciding:", datetime_object_total_d)
    atd=datetime_object_total_d / len(json_data['data'])
    print("Average time spent deciding:", atd)
    print("Average time spent deciding each id:", datetime_object_total_d / count_d)



if __name__ == "__main__":
    main()
